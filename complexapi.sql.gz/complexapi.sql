-- Adminer 4.7.1 PostgreSQL dump

DROP TABLE IF EXISTS "pictures";
DROP SEQUENCE IF EXISTS pictures_id_seq;
CREATE SEQUENCE pictures_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1;

CREATE TABLE "public"."pictures" (
    "id" integer DEFAULT nextval('pictures_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL
) WITH (oids = false);

INSERT INTO "pictures" ("id", "name") VALUES
(1,	'235.jpg'),
(2,	'236.jpg'),
(3,	'237.jpg'),
(4,	'194.jpg');

DROP TABLE IF EXISTS "users";
DROP SEQUENCE IF EXISTS users_id_seq;
CREATE SEQUENCE users_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1;

CREATE TABLE "public"."users" (
    "id" integer DEFAULT nextval('users_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "email" character varying(255) NOT NULL,
    "password" character varying(255) NOT NULL,
    "role" character varying(35) DEFAULT 'user' NOT NULL,
    CONSTRAINT "users_email" UNIQUE ("email")
) WITH (oids = false);

INSERT INTO "users" ("id", "name", "email", "password", "role") VALUES
(7,	'Brad',	'brad@gmail.com',	'$2b$10$monqAFk/otRFv2Ux5sjeg.QeGkuJ7sx1JsC46O8eiJc4JSMVkM01C',	'user'),
(8,	'tony',	'tony@maio.ru',	'$2b$10$/c3JviM5HNp9c5am/B9Xfua38ZHFNzfHVRGQDNM5HeQqm1qqWks2m',	'user');

-- 2019-05-07 17:28:24.279845+05
